package com.example.CRUD.Operations.clinical_trial;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
@Repository
public class TrialRepository {
    private List<Clinical_trial> trials = new ArrayList<>();

    Clinical_trial trial1 = new Clinical_trial("0002","clinical trial title two", "Active","18", "111", "01/01/2024", "01/10/2024", "54");
    Clinical_trial trial2 = new Clinical_trial("0003","clinical trial title three", "Active","18", "111", "01/01/2024", "01/10/2024", "60");

    @PostConstruct
    private void init(){
        trials.add(trial1);
        trials.add(trial2);
    }

    List<Clinical_trial> findAllTrials(){
        return trials;
    }

    Optional<Clinical_trial> findById(String id){
        return trials.stream().filter(trial -> trial.getId().equals(id)).findFirst();

    }

    void createTrial(Clinical_trial trial){
        trials.add(trial);
    }

    void update(Clinical_trial trial, String id){
        Optional<Clinical_trial> existingtrial = findById(id);
        if(existingtrial.isPresent()){
            trials.set(trials.indexOf(existingtrial.get()), trial);

        }

    }

    void delete(String id){
        trials.removeIf(trial -> trial.getId().equals(id));
    }



}



